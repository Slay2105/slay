"""Core package for the TikTok to Facebook re-upload bot."""
